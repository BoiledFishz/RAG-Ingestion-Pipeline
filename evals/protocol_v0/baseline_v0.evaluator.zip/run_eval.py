"""Run the frozen TechQA evaluation protocol without modifying the serving code."""

import logging

from evaluation_protocol.runner import main

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    raise SystemExit(main())
