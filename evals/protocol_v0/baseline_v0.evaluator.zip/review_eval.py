"""Rescore frozen answers using independent annotations, without new held-out inference."""

import logging

from evaluation_protocol.review import main

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    raise SystemExit(main())
