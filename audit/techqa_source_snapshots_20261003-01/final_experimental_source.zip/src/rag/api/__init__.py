"""Optional HTTP API surface."""
