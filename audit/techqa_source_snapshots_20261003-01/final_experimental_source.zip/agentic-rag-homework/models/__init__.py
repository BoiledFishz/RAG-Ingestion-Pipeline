"""Shared models."""
