"""Deterministic structured-output simulator for repeatable, no-network experiments."""

from __future__ import annotations

import ast
import json
import re
from typing import Any


class DemoStructuredModel:
    @staticmethod
    def excerpt(evidence: str) -> str:
        """Keep the test double inside the diagnosis schema's output budget."""
        return evidence if len(evidence) <= 1800 else evidence[:1800].rsplit(" ", 1)[0]

    @staticmethod
    def field(prompt: str, name: str) -> str:
        line = next(line for line in prompt.splitlines() if line.startswith(name + ": "))
        return str(ast.literal_eval(line.split(": ", 1)[1]))

    async def generate(self, prompt: str, schema: dict[str, Any]) -> str:
        if "KIND: FACT_AUDIT" in prompt:
            # Wire-contract test double only. Native experiments always use Ollama.
            evidence = ast.literal_eval(next(line.split(": ", 1)[1] for line in
                prompt.splitlines() if line.startswith("EVIDENCE: ")))
            answer = self.field(prompt, "ANSWER")
            keys = schema["properties"]["required_facts"]["items"]["enum"]
            matching = [(key, value[:80]) for key, value in evidence.items()
                        if value[:80] in answer]
            return json.dumps({"principal_request": "Test-double request",
                "required_facts": keys, "covered_facts": keys if matching else [],
                "missing_facts": [] if matching else keys, "incorrect_facts": [],
                "fact_evidence": [{"fact": fact, "source_id": matching[0][0],
                    "evidence_quote": matching[0][1], "answer_quote": matching[0][1]}
                    for fact in keys] if matching else [],
                "verdict": "pass" if matching else "revise"})
        if "KIND: GROUNDED_DIAGNOSIS" in prompt:
            keys = schema["oneOf"][0]["properties"]["source_ids"]["items"]["enum"]
            return json.dumps({"sufficient": True, "source_ids": keys[:1]})
        if "KIND: EVIDENCE_SELECTOR" in prompt:
            properties = schema["oneOf"][0]["properties"]
            field = "selected" if "selected" in properties else "source_ids"
            keys = properties[field]["items"]["enum"]
            return json.dumps({"sufficient": True, field: keys[:1]})
        if "KIND: PLANNER" in prompt:
            return json.dumps(
                {
                    "tasks": [
                        {
                            "task_id": "T001",
                            "agent": "research_agent",
                            "objective": "Collect evidence relevant to the requested investigation",
                            "dependencies": [],
                        },
                        {
                            "task_id": "T002",
                            "agent": "diagnosis_agent",
                            "objective": (
                                "Produce an evidence-grounded diagnosis and recommendation"
                            ),
                            "dependencies": ["T001"],
                        },
                        {
                            "task_id": "T003",
                            "agent": "report_writer",
                            "objective": "Return the checked result with explicit sources",
                            "dependencies": ["T002"],
                        },
                    ]
                }
            )
        if "KIND: REACT" in prompt:
            # A unit-test model double, with no product-specific knowledge or answers.
            return json.dumps(
                {
                    "action": "finish",
                    "argument": "",
                    "reason": "Inspect existing evidence; runtime validates support",
                }
            )
        if "KIND: DIAGNOSIS" in prompt:
            repaired = "CRITIC_FEEDBACK: []" not in prompt
            evidence = self.field(prompt, "EVIDENCE")
            excerpt = self.excerpt(evidence)
            diagnosis = (
                excerpt + ("" if re.search(r"\[\d+\]", excerpt) else " [evidence]")
                if repaired
                else "Check the related configuration."
            )
            citations = list(dict.fromkeys(re.findall(r"\[(\d+)\]", excerpt)))[:4] or ["evidence"]
            return json.dumps({"diagnosis": diagnosis, "citations": citations}, ensure_ascii=False)
        if "KIND: CRITIC" in prompt:
            evidence = self.field(prompt, "EVIDENCE")
            diagnosis = self.field(prompt, "DIAGNOSIS")

            def clean(value: str) -> str:
                return re.sub(r"\[(?:\d+|evidence)\]", "", value).strip()

            if clean(self.excerpt(evidence)) in clean(diagnosis) and re.search(
                r"\[(?:\d+|evidence)\]",
                diagnosis,
            ):
                return json.dumps({"passed": True, "score": 0.9, "issues": []})
            return json.dumps(
                {
                    "passed": False,
                    "score": 0.45,
                    "issues": [
                        {
                            "code": "missing_evidence",
                            "description": "The diagnosis does not cite retrieved evidence",
                            "suggestion": "Cite evidence and provide verifiable checks",
                        }
                    ],
                },
                ensure_ascii=False,
            )
        raise ValueError("unknown prompt kind")
