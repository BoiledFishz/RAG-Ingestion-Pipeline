"""Vector store package."""
